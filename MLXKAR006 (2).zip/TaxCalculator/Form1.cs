﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TaxCalculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal taxibleincome = Convert.ToDecimal(txtTaxableinc.Text);
            decimal incomeowed = 0;

            if (taxibleincome >= 1 && taxibleincome < 195850)
            {
                incomeowed = taxibleincome * 0.18m;
            }
            else if (taxibleincome >= 195851 && taxibleincome < 305850)
            {
                incomeowed = 35253 + (taxibleincome - 195850) * 0.26m;
            }
            else if (taxibleincome >= 305851 && taxibleincome < 423300)
            {
                incomeowed = 63853 + (taxibleincome - 305850) * 0.31m;
            }
            else if (taxibleincome >= 423301 && taxibleincome < 555600)
            {
                incomeowed = 100263 + (taxibleincome - 423300) * 0.36m;
            }
            else if (taxibleincome >= 555601 && taxibleincome < 708310)
            {
                incomeowed = 147891 + (taxibleincome - 555600) * 0.39m;
            }
            else if (taxibleincome >= 423301 && taxibleincome < 555600)
            {

            }
            else if (taxibleincome >= 423301 && taxibleincome < 555600)
            {

            }
            txtIncomeTaxowed .Text = incomeowed.ToString("c");
        }
    }
}
